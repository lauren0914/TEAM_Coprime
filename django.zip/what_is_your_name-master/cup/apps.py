from django.apps import AppConfig


class CupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cup'
